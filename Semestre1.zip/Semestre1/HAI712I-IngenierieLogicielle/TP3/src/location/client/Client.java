package location.client;

public class Client
{
	private String nom;
	
	public Client(String nom)
	{
		this.nom = nom;
	}
	
	public String getNom()
	{
		return this.nom;
	}
}
