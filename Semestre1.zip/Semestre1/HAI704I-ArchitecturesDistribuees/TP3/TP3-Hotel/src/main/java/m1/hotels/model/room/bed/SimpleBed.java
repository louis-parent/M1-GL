﻿package m1.hotels.model.room.bed;

public class SimpleBed implements Bed
{
	public int getPersonAmount()
	{
		return 1;
	}
}
