﻿package m1.hotels.model.room.bed;

public class DoubleBed implements Bed
{
	public int getPersonAmount()
	{
		return 2;
	}
}