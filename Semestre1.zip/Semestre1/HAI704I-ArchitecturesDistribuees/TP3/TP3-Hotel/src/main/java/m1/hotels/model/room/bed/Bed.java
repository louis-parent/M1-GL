﻿package m1.hotels.model.room.bed;

public interface Bed
{
	public abstract int getPersonAmount();
}
