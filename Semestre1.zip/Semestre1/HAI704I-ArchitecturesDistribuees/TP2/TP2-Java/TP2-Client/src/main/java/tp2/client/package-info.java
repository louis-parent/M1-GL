@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.server.tp2/")
package tp2.client;
