package tp2.client.ui.listener.reservation;

public interface ReservationListener
{
	public abstract void reservationDone();
}
