package tp2.client.ui.listener.filter;

public interface OfferFilterListener
{
	public abstract void filter(int stars, float maxPrice);
}
