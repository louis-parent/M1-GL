﻿package tp2.server.model.room.bed;

public interface Bed
{
	public abstract int getPersonAmount();
}
