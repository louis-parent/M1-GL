﻿package tp2.server.model.room.bed;

public class DoubleBed implements Bed
{
	public int getPersonAmount()
	{
		return 2;
	}
}