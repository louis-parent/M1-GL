﻿package tp2.server.model.room.bed;

public class SimpleBed implements Bed
{
	public int getPersonAmount()
	{
		return 1;
	}
}
