package m1.hotels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp3ServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
