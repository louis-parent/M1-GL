package m1.agencies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp3AgencyApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp3AgencyApplication.class, args);
	}

}
