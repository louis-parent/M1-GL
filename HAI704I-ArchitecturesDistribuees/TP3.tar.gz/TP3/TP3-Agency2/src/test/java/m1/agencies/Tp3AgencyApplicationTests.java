package m1.agencies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp3AgencyApplicationTests {

	@Test
	void contextLoads() {
	}

}
